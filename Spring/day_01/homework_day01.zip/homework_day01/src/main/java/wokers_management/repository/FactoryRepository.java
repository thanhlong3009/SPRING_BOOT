package wokers_management.repository;

import wokers_management.database.FactoryDB;
import wokers_management.model.Factory;

import java.util.Scanner;

public class FactoryRepository {
    Scanner sc = new Scanner(System.in);

    public void add_factory() {

        System.out.print("Nhập tên: ");
        String name = sc.nextLine();
        System.out.print("Mô tả công việc: ");
        String description = sc.nextLine();
        System.out.print("Nhập hệ số công việc: ");
        Double jobCoefficient = Double.parseDouble(sc.nextLine());
        Factory factory = new Factory(name,description,jobCoefficient);
        FactoryDB.factories.add(factory);
        System.out.println("Thêm xưởng mới thành công");
    }

    public void show_factories() {
        System.out.println("Danh sách xưởng");
        for (Factory factory: FactoryDB.factories) {
            System.out.println(factory);
        }
    }
}
