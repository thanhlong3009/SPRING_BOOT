package wokers_management.database;

import wokers_management.model.Factory;

import java.util.ArrayList;
import java.util.List;

public class FactoryDB {
    public static ArrayList<Factory> factories = new ArrayList<>();
}
