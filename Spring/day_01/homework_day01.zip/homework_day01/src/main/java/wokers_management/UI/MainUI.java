package wokers_management.UI;

import wokers_management.repository.FactoryRepository;
import wokers_management.repository.WorkerRepository;

import java.util.Scanner;

public class MainUI {
    FactoryRepository factoryRepository = new FactoryRepository();
    WorkerRepository workerRepository = new WorkerRepository();

    public void run() {
        Scanner sc = new Scanner(System.in);
        boolean isQuit = false;
        int option = 0;
        while (!isQuit) {
            menu();
            System.out.print("Nhập lựa chọn: ");
            option = Integer.parseInt(sc.nextLine());

            switch (option) {
                case 1: {
                    workerRepository.add_worker();
                    workerRepository.show_workers();
                    break;
                }
                case 2: {
                    factoryRepository.add_factory();
                    factoryRepository.show_factories();
                    break;
                }
                default: {
                    System.out.println("Nhập không đúng, nhập lại!");
                }
            }
        }
    }

    public void menu() {
        System.out.println("1 - Thêm công nhân mới");
        System.out.println("2 - Thêm xưởng mới");
    }
}
