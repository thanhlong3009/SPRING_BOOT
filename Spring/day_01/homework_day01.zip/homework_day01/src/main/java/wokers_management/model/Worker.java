package wokers_management.model;

import lombok.*;


@NoArgsConstructor
@Data
public class Worker {
    private static int count = 1000;
    private int id;
    private String name;
    private String address;
    private String phone;
    private int rank;

    public Worker(String name, String address, String phone, int rank) {
        this.id = count++;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.rank = rank;
    }


}
