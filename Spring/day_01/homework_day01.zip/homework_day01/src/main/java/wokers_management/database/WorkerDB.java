package wokers_management.database;

import wokers_management.model.Worker;

import java.util.ArrayList;
import java.util.List;

public class WorkerDB {
    public static ArrayList<Worker> workers = new ArrayList<>();
}
