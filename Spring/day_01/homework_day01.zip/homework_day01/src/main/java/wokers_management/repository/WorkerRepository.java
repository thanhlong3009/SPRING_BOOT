package wokers_management.repository;

import wokers_management.model.Worker;
import wokers_management.database.WorkerDB;

import java.util.Scanner;

public class WorkerRepository {
    Scanner sc = new Scanner(System.in);


    public void add_worker() {
        System.out.print("Nhập tên: ");
        String name = sc.nextLine();
        System.out.print("Nhập địa chỉ: ");
        String address = sc.nextLine();
        System.out.print("Nhập số điện thoại: ");
        String phone = sc.nextLine();
        System.out.print("Nhập bậc thợ: ");
        int rank = Integer.parseInt(sc.nextLine());
        Worker worker = new Worker(name,address,phone,rank);
        WorkerDB.workers.add(worker);

        System.out.println("Thêm công nhân mới thành công");
    }

    public void show_workers() {
        System.out.println("Danh sách công nhân:");
        for (Worker worker: WorkerDB.workers) {
            System.out.println(worker);
        }
    }


}
