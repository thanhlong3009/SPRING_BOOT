package wokers_management.model;

import lombok.*;

@NoArgsConstructor
@Data
public class Factory {
    private static   int count = 100;
    private int id;
    private String name;
    private String description;
    private double jobCoefficient;


    public Factory(String name, String description, double jobCoefficient) {
        this.id = count++;
        this.name = name;
        this.description = description;
        this.jobCoefficient = jobCoefficient;
    }

}
