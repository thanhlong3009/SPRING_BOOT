package entity;

public interface InputInfo {
    void inputInfo();
}
