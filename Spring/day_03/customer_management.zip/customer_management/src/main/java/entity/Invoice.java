package entity;

import java.util.List;

public class Invoice{
    private Customer customer;
    private List<InvoiceDetail> invoiceDetails;

    public Invoice(Customer customer, List<InvoiceDetail> invoiceDetails) {
        this.customer = customer;
        this.invoiceDetails = invoiceDetails;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<InvoiceDetail> getInvoiceDetails() {
        return invoiceDetails;
    }

    public void setInvoiceDetails(List<InvoiceDetail> invoiceDetails) {
        this.invoiceDetails = invoiceDetails;
    }

    public int getTotalQuantity() {
        int totalQuantity = 0;
        for (InvoiceDetail detail : invoiceDetails) {
            totalQuantity += detail.getQuantity();
        }
        return totalQuantity;
    }

    @Override
    public String toString() {
        return "Invoice{" +
                "customer=" + customer +
                ", invoiceDetails=" + invoiceDetails +
                '}';
    }


}
