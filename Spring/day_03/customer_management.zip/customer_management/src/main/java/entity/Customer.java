package entity;

import statics.CustomerType;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Customer extends Person {
    private int id;
    private CustomerType customerType;

    private static int AUTO_ID = 10000;

    public Customer() {
        this.id = AUTO_ID;
        AUTO_ID++;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", customerType=" + customerType +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }

    @Override
    public void inputInfo() {
        super.inputInfo();
        System.out.println("Nhập loại khách hàng: ");
        System.out.println("1. khách hàng cá nhân");
        System.out.println("2. Khách hàng đại diện đơn vị hành chính");
        System.out.println("3. Khách hàng đại diện đơn vị kinh doanh");
        int choice;
        do {
            try {
                choice = new Scanner(System.in).nextInt();
                if (choice >= 1 && choice <= 3) {
                    break;
                }
                System.out.println("Lựa chọn không hợp lệ, vui lòng chọn lại: ");
            } catch (InputMismatchException ex) {
                System.out.println("Vui lòng nhập số từ 1 tới 3: ");
            }
        } while (true);
        switch (choice) {
            case 1:
                this.setCustomerType(CustomerType.INDIVIDUAL);
                break;
            case 2:
                this.setCustomerType(CustomerType.ADMINISTRATIVE_UNIT);
                break;
            case 3:
                this.setCustomerType(CustomerType.BUSINESS_UNIT);
                break;
        }
    }
}
