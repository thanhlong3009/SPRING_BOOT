package statics;

public enum CustomerType {
    INDIVIDUAL(1),
    ADMINISTRATIVE_UNIT(2),
    BUSINESS_UNIT(3),
    ;

    public int type;
    CustomerType(int type) {
        this.type = type;
    }
}
