package logic_handle;

import entity.Customer;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class CustomerManagement {
    private List<Customer> customers;

    public CustomerManagement() {
        this.customers = new ArrayList<>();
    }
    public void inputInfo() {
        System.out.println("Bạn muốn nhập cho bao nhiêu khách hàng: ");
        int customerNumber = staticMethodManagement.numberInput();

        for (int i = 0; i < customerNumber; i++) {
            Customer customer = new Customer();
            customer.inputInfo();
            customers.add(customer);
        }
        showCustomer();
    }

    public void showCustomer() {
        customers.forEach(System.out::println);
    }

    public Customer findById(int id) {
        for (Customer customer : customers) {
            if (customer.getId() == id) {
                return customer;
            }
        }
        return null;
    }

}
