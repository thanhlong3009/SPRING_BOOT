package logic_handle;

import entity.Customer;
import entity.Invoice;
import entity.InvoiceDetail;
import entity.Service;

import java.util.*;

public class InvoiceManagement {
    private List<Invoice> invoices;
    private CustomerManagement customerManagement;
    private ServiceManagement serviceManagement;

    public InvoiceManagement( CustomerManagement customerManagement, ServiceManagement serviceManagement) {
        this.invoices = new ArrayList<>();
        this.customerManagement = customerManagement;
        this.serviceManagement = serviceManagement;
    }

    public void logInvoice() {
        System.out.println("Muốn nhập hóa đơn cho bao nhiêu khách hàng:");
        int customerNumber = staticMethodManagement.numberInput();

        for (int i = 0; i < customerNumber; i++) {
            System.out.println("Nhập ID của khách hàng thứ " + (i + 1) + " mà bạn muốn chấm công: ");
            int customerId;
            Customer customer;
            do {
                try {
                    customerId = new Scanner(System.in).nextInt();
                    customer = customerManagement.findById(customerId);
                    if (customer != null) {
                        break;
                    }
                    System.out.println("ID không tồn tại trong hệ thống, vui lòng nhập lại: ");
                } catch (InputMismatchException ex) {
                    System.out.println("Vui lòng nhập số: ");
                }
            } while (true);

            System.out.println("Khách hàng này sử dụng bao nhiêu dịch vụ");
            int serviceNumber = staticMethodManagement.numberInput();

            List<InvoiceDetail> invoiceDetails = new ArrayList<>();
            for (int j = 0; j < serviceNumber; j++) {
                System.out.println("Nhập mã dịch vụ thứ " + (j + 1) + " mà khách hàng này đã sử dụng: ");
                int serviceId;
                Service service;
                do {
                    try {
                        serviceId = new Scanner(System.in).nextInt();
                        service = serviceManagement.findById(serviceId);
                        if (service != null ) {
                            break;
                        }
                        System.out.println("ID không tồn tại trong hệ thống, vui lòng nhập lại: ");
                    } catch (InputMismatchException ex) {
                        System.out.println("Vui lòng nhập số: ");
                    }
                } while (true);

                System.out.println("khách hàng này sử dụng dịch vụ " + service.getName() + " với số lượng bao nhiêu");
                int quantity = staticMethodManagement.numberInput();

                InvoiceDetail invoiceDetail = new InvoiceDetail(service, quantity);
                invoiceDetails.add(invoiceDetail);
            }

            Invoice invoice = new Invoice(customer, invoiceDetails);
            invoices.add(invoice);
        }
        showInfo();

    }

    public void showInfo() {
        invoices.forEach(System.out::println);
    }

    public void sortByName() {
        Comparator<Invoice> customerNameComparator = new Comparator<Invoice>() {
            @Override
            public int compare(Invoice i1, Invoice i2) {
                return i1.getCustomer().getName().compareTo(i2.getCustomer().getName());
            }
        };
        invoices.sort(customerNameComparator);
        showInfo();
    }

    public void sortByQuantity() {
        Comparator<Invoice> quantityComparator = new Comparator<Invoice>() {
            @Override
            public int compare(Invoice i1, Invoice i2) {
                return Integer.compare(i2.getTotalQuantity(), i1.getTotalQuantity());
            }
        };
        invoices.sort(quantityComparator);
        showInfo();
    }

    public Map<String,Double> totalPriceOfCustomer() {
        Map<String, Double> result = new HashMap<>();

        for (Invoice invoice : invoices) {
            String customerName = invoice.getCustomer().getName();
            List<InvoiceDetail> invoiceDetails = invoice.getInvoiceDetails();

            double totalPrice= 0;
            for (InvoiceDetail i : invoiceDetails) {
                totalPrice += i.getService().getPrice() * i.getQuantity();
            }

            if (result.containsKey(customerName)) {
                totalPrice += result.get(customerName);
            }
            result.put(customerName, totalPrice);
        }
        return result;
    }

}
