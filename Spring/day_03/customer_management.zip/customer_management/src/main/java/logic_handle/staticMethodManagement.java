package logic_handle;

import java.util.InputMismatchException;
import java.util.Scanner;

public class staticMethodManagement {
    public static int numberInput() {
        int number;
        do {
            try {
                number = new Scanner(System.in).nextInt();
                if (number > 0) {
                    break;
                }
                System.out.println("Số lượng nhập vào phải lớn hơn 0 và nhỏ hơn bằng max, nhập lại: ");
            } catch (InputMismatchException ex) {
                System.out.println("Vui lòng nhập số: ");
            }
        } while (true);
        return number;
    }

}
