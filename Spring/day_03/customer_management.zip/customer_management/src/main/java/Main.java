import logic_handle.MenuManagement;

public class Main {
    public static void main(String[] args) {
        MenuManagement menuManagement = new MenuManagement();
        menuManagement.menu();
    }
}
