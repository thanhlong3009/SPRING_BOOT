package com.example.demo_tl.service;

import com.example.demo_tl.model.Teacher;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TeacherService {
    private static final List<Teacher> teachers = new ArrayList<>();

    public void createDataTeacher() {
        for (int i = 0; i < 10; i++) {
            Teacher teacher = Teacher.builder()
                    .id(i)
                    .name("Nguyen Thi " + i)
                    .address("Ha Noi "+ i)
                    .dob(LocalDate.now())
                    .specialization("spec " + i)
                    .level("level " + i)
                    .build();
            teachers.add(teacher);
        }
        System.out.println("askkkkk");
    }

    public List<Teacher> getAllTeachers() {
        System.out.println("da lay ra list");
        return teachers;
    }

    public void saveTeacher(Teacher teacher) {
        System.out.println("da luu vao list");
        teachers.add(teacher);
    }

    public Teacher findById(int id) {
        for (Teacher teacher : teachers) {
            if (teacher.getId() == id) {
                System.out.println("da tim thay GV theo Id");
                return teacher;
            }
        }
        return null;
    }

    public void deleteById(int id) {
        teachers.removeIf(teacher -> teacher.getId() == id);
        System.out.println("Da delete");
    }

    public void updateTeacher(Teacher teacher,int id) {
        Teacher teacher1 = findById(id);
        teacher1.setName(teacher.getName());
        teacher1.setAddress(teacher.getAddress());
        teacher1.setGender(teacher.getGender());
        teacher1.setDob(teacher.getDob());
        teacher1.setSpecialization(teacher.getSpecialization());
        teacher1.setLevel(teacher.getLevel());
    }
}
