package com.example.demo_tl.controller;

import com.example.demo_tl.model.Student;
import com.example.demo_tl.model.Teacher;
import com.example.demo_tl.service.TeacherService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/teachers")
@AllArgsConstructor
public class TeacherController {

    public TeacherService teacherService;

    @GetMapping
    public String getTeachers(Model model) {
        List<Teacher> teachers = teacherService.getAllTeachers();
        model.addAttribute("danhSachGiaoVien",teachers);
        return "teacher-list";
    }

    @GetMapping("/create-form")
    public String forwardToCreateForm(Model model, Teacher teacher) {
        model.addAttribute("giaoVienToiMuonTaoMoi",teacher);
        return "create-teacher";
    }

    @PostMapping
    public String saveTeacher(@ModelAttribute("task") Teacher teacher) {
        teacherService.saveTeacher(teacher);
        return "redirect:/teachers";
    }

    @GetMapping("/{id}/update")
    public String forwardToUpdateForm(@PathVariable int id, Model model) {
        Teacher teacher = teacherService.findById(id);
        model.addAttribute("giaoVienToiMuonCapNhat", teacher);
        return "update-teacher";
    }

    @PostMapping("/{id}/update")
    public String updateTeacher(@ModelAttribute("task") Teacher teacher,@PathVariable int id) {
        teacherService.updateTeacher(teacher,id);
        return "redirect:/teachers";
    }

    @PostMapping("/{id}/delete")
    public String deleteTeacher(@PathVariable int id) {
        teacherService.deleteById(id);
        return "redirect:/teachers";
    }

}
