package com.example.demo_tl.service;

import com.example.demo_tl.model.Student;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
public class StudentService {
    private static final List<Student> students = new ArrayList<>();

    public void createDataStudent() {
        for (int i = 0; i < 10; i++) {
            Student student = Student.builder()
                    .id(i)
                    .name("Nguyen Van " + i)
                    .address("Ha Noi "+ i)
                    .phone("0909090" + i)
                    .dob(LocalDate.now())
                    .gpa(i)
                    .build();
            students.add(student);
        }
    }

    public List<Student> getAllStudents() {
        createDataStudent();
        return students;
    }

    public void saveStudent(Student student) {
        students.add(student);
    }
}
