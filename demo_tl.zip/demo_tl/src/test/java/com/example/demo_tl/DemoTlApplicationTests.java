package com.example.demo_tl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTlApplicationTests {

    @Test
    void contextLoads() {
    }

}
